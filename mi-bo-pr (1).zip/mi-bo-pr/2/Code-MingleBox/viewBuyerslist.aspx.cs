using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class viewBuyerslist : System.Web.UI.Page
{
    string sqlConnection;
    SqlConnection cn;
    public viewBuyerslist()
    {
        sqlConnection = ConfigurationManager.ConnectionStrings["codeshare"].ConnectionString;
        cn = new SqlConnection(sqlConnection);
        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
 
        }
    }
    private void DataBind()
    {
        string sqlQuery = "Select *,fname+' '+lname as name from bid_projects where Access_rights_id='222'";
        DataSet dsProj = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
        da.Fill(dsProj);
        GridView1.DataSource = dsProj.Tables[0].DefaultView;
        GridView1.DataBind();
    }
    protected void lbBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Administrator.aspx");
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int index = e.RowIndex;
            int id = Convert.ToInt32(GridView1.DataKeys[index].Value);
            string sqlQuery = "delete from bid_projects where id=" + id;
            SqlCommand cmd = new SqlCommand(sqlQuery,cn);
            cmd.ExecuteNonQuery();
            DataBind();
        }
        catch(Exception ex)
        { 
        }
    }
    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowIndex > -1)
        {
            DataRowView dv = (DataRowView)e.Row.DataItem;
            
        }
    }
}
