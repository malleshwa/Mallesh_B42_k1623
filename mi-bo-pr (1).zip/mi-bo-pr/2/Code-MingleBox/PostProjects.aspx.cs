using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class PostProjects : System.Web.UI.Page
{
    string sqlConnection;
    SqlConnection cn;
    public PostProjects()
    {
        sqlConnection = ConfigurationManager.ConnectionStrings["codeshare"].ConnectionString;
        cn = new SqlConnection(sqlConnection);
        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["usertype"].ToString() == "111")
        {
            btnSubmit.Visible = false;
            lbBack.Visible = true;
            lbBack0.Visible = false;


        }
        else
        {
            btnSubmit.Visible = true;
            lbBack.Visible = false;
            lbBack0.Visible = true;
        }
        if (!IsPostBack)
        {
            if (Request.QueryString["Pid"] == null)
            {
                for (int i = 1; i <= 31; i++)
                {
                    ddlDate.Items.Add(new ListItem(i.ToString(), i.ToString()));
                }
                ddlMonth.Items.Add(new ListItem("Jan", "1"));
                ddlMonth.Items.Add(new ListItem("Feb", "2"));
                ddlMonth.Items.Add(new ListItem("Mar", "3"));
                ddlMonth.Items.Add(new ListItem("Apr", "4"));
                ddlMonth.Items.Add(new ListItem("May", "5"));
                ddlMonth.Items.Add(new ListItem("Jun", "6"));
                ddlMonth.Items.Add(new ListItem("Jul", "7"));
                ddlMonth.Items.Add(new ListItem("Aug", "8"));
                ddlMonth.Items.Add(new ListItem("Sep", "9"));
                ddlMonth.Items.Add(new ListItem("Oct", "10"));
                ddlMonth.Items.Add(new ListItem("Nov", "11"));
                ddlMonth.Items.Add(new ListItem("Dec", "12"));
                for (int j = 1990; j <= 2020; j++)
                {
                    ddlYear.Items.Add(new ListItem(j.ToString(), j.ToString()));
                }
                Category.Items.Add("Networking");
                Category.Items.Add("System Software");
                Category.Items.Add("Application");
                GetProjectID();
                txtBuyerName.Text = Session["id"].ToString();
            }
            else
            {
                for (int i = 1; i <= 31; i++)
                {
                    ddlDate.Items.Add(new ListItem(i.ToString(), i.ToString()));
                }
                ddlMonth.Items.Add(new ListItem("Jan", "1"));
                ddlMonth.Items.Add(new ListItem("Feb", "2"));
                ddlMonth.Items.Add(new ListItem("Mar", "3"));
                ddlMonth.Items.Add(new ListItem("Apr", "4"));
                ddlMonth.Items.Add(new ListItem("May", "5"));
                ddlMonth.Items.Add(new ListItem("Jun", "6"));
                ddlMonth.Items.Add(new ListItem("Jul", "7"));
                ddlMonth.Items.Add(new ListItem("Aug", "8"));
                ddlMonth.Items.Add(new ListItem("Sep", "9"));
                ddlMonth.Items.Add(new ListItem("Oct", "10"));
                ddlMonth.Items.Add(new ListItem("Nov", "11"));
                ddlMonth.Items.Add(new ListItem("Dec", "12"));
                for (int j = 1990; j <= 2020; j++)
                {
                    ddlYear.Items.Add(new ListItem(j.ToString(), j.ToString()));
                }
                Category.Items.Add("Networking");
                Category.Items.Add("System Software");
                Category.Items.Add("Application");
                string sqlQuery = "Select * from proj_desc where P_ID=" + Convert.ToInt32(Request.QueryString["Pid"]);
                SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    txtProjID.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
                    txtProjectName.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
                    Category.Items.Add(ds.Tables[0].Rows[0].ItemArray[2].ToString());
                    txtProjDesc.Text = ds.Tables[0].Rows[0].ItemArray[3].ToString();
                    string[] dates = ds.Tables[0].Rows[0].ItemArray[4].ToString().Split('/');
                    ddlDate.Items.FindByValue(dates[1]).Selected=true;
                    ddlMonth.Items.FindByValue(dates[0]).Selected=true;
                    ddlYear.Items.FindByValue(dates[2]).Selected=true;
                    txtMinAmt.Text = ds.Tables[0].Rows[0].ItemArray[5].ToString();
                    txtBuyerName.Text = ds.Tables[0].Rows[0].ItemArray[6].ToString();
                    btnSubmit.Visible = false;
                }

            }
        }
    }
    private void GetProjectID()
    {
        string sqlQuery = "Select max(P_ID) from proj_desc";
        SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds != null && ds.Tables[0].Rows.Count>0)
        {
            int x=Convert.ToInt32(ds.Tables[0].Rows[0].ItemArray[0]);
            x = x + 1;
            txtProjID.Text = x.ToString();
        }
    }
   
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string date = ddlMonth.SelectedItem.Value + "/" + ddlDate.SelectedItem.Text + "/" + ddlYear.SelectedItem.Value;
            string sqlQuery = "insert into proj_desc values('" + txtProjectName.Text + "','" + Category.SelectedItem.Text + "','" + txtProjDesc.Text + "','" + date + "','" + txtMinAmt.Text + "'," + Convert.ToInt32(Session["id"]) + ",'" + false + "')";
            SqlCommand cmd = new SqlCommand(sqlQuery, cn);
            cmd.ExecuteNonQuery();
            //Response.Redirect("ViewAllProjects.aspx");
        }
        catch (Exception x)
        {
            lblMsg.Visible = true;
            lblMsg.Text = "Process Failed, Try Again";
        }
    }
    protected void lbBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("coder.aspx");
    }
    protected void lbBack0_Click(object sender, EventArgs e)
    {
        Response.Redirect("Buyer.aspx");
    }
}
