using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class ViewOpenProjects : System.Web.UI.Page
{
    string sqlConnection;
    SqlConnection cn;
    public ViewOpenProjects()
    {
        sqlConnection = ConfigurationManager.ConnectionStrings["codeshare"].ConnectionString;
        cn = new SqlConnection(sqlConnection);
        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataSet dsTemp = new DataSet();
            DataTable dt = new DataTable();
            DataRow dr;
            dt.Columns.Add("BidCount", Type.GetType("System.Int32"));
            dt.Columns.Add("p_id", Type.GetType("System.Int32"));
            dt.Columns.Add("p_Name", Type.GetType("System.String"));
            dt.Columns.Add("p_type", Type.GetType("System.String"));
            dt.Columns.Add("email", Type.GetType("System.String"));
            string sqlQuery = "select p.P_ID,p.P_Name,p.P_Type,p.P_Description,b.email from proj_desc p,bid_projects b where p.P_ID=b.id order by p.P_ID";
            SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                   dr=dt.NewRow();
                   dr[0] = GetCount(Convert.ToInt32(ds.Tables[0].Rows[i].ItemArray[0]));
                   dr[1] = ds.Tables[0].Rows[i].ItemArray[0].ToString();
                   dr[2] = ds.Tables[0].Rows[i].ItemArray[1].ToString();
                   dr[3] = ds.Tables[0].Rows[i].ItemArray[2].ToString();
                   dr[4] = ds.Tables[0].Rows[i].ItemArray[4].ToString();
                   dt.Rows.Add(dr);
                }
            }
            dsTemp.Tables.Add(dt);
            GridView1.DataSource = dsTemp.Tables[0].DefaultView;
            GridView1.DataBind();           
        }

    }
    private int GetCount(int pid)
    {
        string sqlQuery = " select count(P_ID) from bid where p_id=" + pid;
        SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return Convert.ToInt32(ds.Tables[0].Rows[0].ItemArray[0]);
    }
    protected void lbBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Buyer.aspx");
    }
}
