using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Registration : System.Web.UI.Page
{
    string sqlConnection;
    SqlConnection cn;
    public Registration()
    {
        sqlConnection = ConfigurationManager.ConnectionStrings["codeshare"].ConnectionString;
        cn = new SqlConnection(sqlConnection);
        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            GetCustID();
    }
    protected void lbBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("CoderBuyerLogin.aspx");
    }

    protected void btnSginIn_Click(object sender, EventArgs e)
    {
        string type="";
        if(DropDownList1.SelectedItem.Value=="Coder")
            type="111";
        else
            type="222";
        if (CheckUserName())
        {
          //  try
            {
//
                string sqlQuery = "insert into bid_projects values('" + txtUserName.Text + "','" + txtPassword.Text + "','" + TXTFNAME.Text + "','" + TXTMNAME.Text + "','" + txtLastName.Text + "','" + TXTMAIL.Text + "','" + TXTPNO.Text + "','" + TXTFAX.Text + "','" + txtmobile.Text + "','" + TXTCONT.Text + "','" + type + "')";
                SqlCommand sqlCmd = new SqlCommand(sqlQuery, cn);
                sqlCmd.ExecuteNonQuery();
                Response.Redirect("CoderBuyerLogin.aspx");

            }
        //    catch (Exception x)
        //    {
        //        lblMsg.Visible = true;
        //        lblMsg.Text = "Sing In Failed , TryAgain";
        //    }
        }
        //else
        //{
        //    lblMsg1.Visible = true;
        //    lblMsg1.Text = "UserName already Exists";
        //}
       
    }
    private void GetCustID()
    {
        string sqlQuery = "select Max(id) from bid_projects";
        SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds != null && ds.Tables[0].Rows.Count > 0)
        {
            int id = Convert.ToInt32(ds.Tables[0].Rows[0].ItemArray[0]);
            id = id + 1;
            TXTID.Text = id.ToString(); ;
        }
        else
        {
            TXTID.Text = "1";
        }
    }
   private bool CheckUserName()
    {
        string type = "";
        if (DropDownList1.SelectedItem.Value == "Coder")
            type = "111";
        else
            type = "222";
        string sqlQuery = "select * from bid_projects where UserName='" + txtUserName.Text + "' and Access_rights_id='"+ type +"' ";
        SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds != null && ds.Tables[0].Rows.Count > 0)       
            return false;       
        else
            return true;
 
    }
   protected void btnCancel_Click(object sender, EventArgs e)
   {
       Response.Redirect("CoderBuyerLogin.aspx");
   }
}
