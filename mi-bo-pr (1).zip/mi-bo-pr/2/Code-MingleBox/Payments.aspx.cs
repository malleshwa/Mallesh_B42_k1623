using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Payments : System.Web.UI.Page
{
    string sqlConnection;
    SqlConnection cn;
    public Payments()
    {
        sqlConnection = ConfigurationManager.ConnectionStrings["codeshare"].ConnectionString;
        cn = new SqlConnection(sqlConnection);
        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
            for (int i = 0; i <= 31; i++)
            {
                ddlDate.Items.Add(new ListItem(i.ToString(), i.ToString()));
            }
          
            ddlMonth.Items.Add("Jan");
            ddlMonth.Items.Add("Feb");
            ddlMonth.Items.Add("Mar");
            ddlMonth.Items.Add("Apr");
            ddlMonth.Items.Add("May");
            ddlMonth.Items.Add("Jun");
            ddlMonth.Items.Add("Jul");
            ddlMonth.Items.Add("Aug");
            ddlMonth.Items.Add("Sep");
            ddlMonth.Items.Add("Oct");
            ddlMonth.Items.Add("Nov");
            ddlMonth.Items.Add("Dec");

         
            ddlYear.Items.Add("2007");
            ddlYear.Items.Add("2008");
            ddlYear.Items.Add("2009");
            ddlYear.Items.Add("2010");

        }

    }
    protected void Submit1_ServerClick(object sender, EventArgs e)
    {
        try
        {            
            string date=ddlDate.SelectedItem.Value+"/"+ddlMonth.SelectedItem.Value+"/"+ddlYear.SelectedItem.Value;
            string sqlQuery = "Insert into Payments values('"+txtfname.Text+"','"+txtlname.Text+"','"+txtemail.Text+"','"+txtAddress.Text+"','"+txtcreditcardNo.Text+"','"+txtCardHolderName.Text+"','"+date+"')";
            SqlCommand cmd = new SqlCommand(sqlQuery, cn);
            cmd.ExecuteNonQuery();
            Response.Redirect("Buyer.aspx");
        }
        catch (Exception ex)
        { 
        }
    }
}
