using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using System.Web.Mail;

public partial class SendMail : System.Web.UI.Page
{
    string sqlConnection;
    SqlConnection cn;
    public SendMail()
    {
        sqlConnection = ConfigurationManager.ConnectionStrings["codeshare"].ConnectionString;
        cn = new SqlConnection(sqlConnection);
        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["admin"] != "yes")
            {
                txtTo.Text = Request.QueryString["email"];
                txtFrom.Text = GetEmail();
            }
            else
            {
                txtTo.Text = Request.QueryString["email"];
                txtFrom.Text = "admin@sify.com";
 
            }
 
        }


    }
    private string GetEmail()
    {
        string sqlQuery = " select email from bid_projects where id=" +Convert.ToInt32(Session["id"]) ;
        SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        string mail="";
        if (ds != null && ds.Tables[0].Rows.Count > 0)
        {
            mail= ds.Tables[0].Rows[0].ItemArray[0].ToString();
        }
        return mail;
   
    }
    protected void btnSend_Click(object sender, EventArgs e)
    {
        try
        {
            MailMessage mail = new MailMessage();
            mail.From = txtFrom.Text;
            mail.To = txtTo.Text;
            mail.Subject = txtSubject.Text;
            mail.Body = txtBody.Text; mail.BodyFormat = MailFormat.Html;
            string strDir="";
            string fileName="";
            if (FileUpload1.HasFile == true)
            {
                strDir = HttpContext.Current.Server.MapPath("Mail\\");
                fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
                FileUpload1.PostedFile.SaveAs(strDir + fileName);
                mail.Attachments.Add(new MailAttachment(strDir + fileName));
            }
            SmtpMail.Send(mail);
            File.Delete(strDir + fileName);
        }
        catch (Exception ex)
        {
            
        }

    }
}
