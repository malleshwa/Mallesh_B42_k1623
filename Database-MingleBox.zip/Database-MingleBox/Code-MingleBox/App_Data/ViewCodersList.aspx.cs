using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class ViewCodersList : System.Web.UI.Page
{
    string sqlConnection;
    SqlConnection cn;
    public ViewCodersList()
    {
        sqlConnection = ConfigurationManager.ConnectionStrings["codeshare"].ConnectionString;
        cn = new SqlConnection(sqlConnection);
        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string sqlQuery = "select * from cust_det";
            DataSet dsProj = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
            da.Fill(dsProj);
            GridView1.DataSource = dsProj.Tables[0].DefaultView;
            GridView1.DataBind(); 
            dsProj = new DataSet();
             da = new SqlDataAdapter(sqlQuery, cn);
            da.Fill(dsProj);
            GridView1.DataSource = dsProj.Tables[0].DefaultView;
            GridView1.DataBind();
        }
    }
    protected void lbBack_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["admin"] == "yes")
            Response.Redirect("Administrator.aspx");
        else
            Response.Redirect("Buyer.aspx");
    }
}
