using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class ViewBidProjects : System.Web.UI.Page
{
    string sqlConnection;
    SqlConnection cn;
    public ViewBidProjects()
    {
        sqlConnection = ConfigurationManager.ConnectionStrings["codeshare"].ConnectionString;
        cn = new SqlConnection(sqlConnection);
        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string sqlQuery = "select b.B_ID,b.B_Amount,a.fname+' '+a.lname as name,a.email from bid_projects a,bid b where b.c_Name=a.id and P_Id="+ Convert.ToInt32(Request.QueryString["bid"]);
            SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds.Tables[0].DefaultView;
            GridView1.DataBind();
        }
    }
    protected void lbBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewOpenProjects.aspx");
    }
}
