using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class ViewAllProjects : System.Web.UI.Page
{
    string sqlConnection;
    SqlConnection cn;
    public ViewAllProjects()
    {
        sqlConnection = ConfigurationManager.ConnectionStrings["codeshare"].ConnectionString;
        cn = new SqlConnection(sqlConnection);
        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        string sqlQuery = "Select p.P_ID,p.P_Name,p.P_Type,p.AmountBid,b.email from proj_desc p,bid_projects b where p.P_ID=b.id order by p.P_ID";
        DataSet dsProj = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(sqlQuery, cn);
        da.Fill(dsProj);
        GridView1.DataSource = dsProj.Tables[0].DefaultView;
        GridView1.DataBind();
    }

    protected void lbBack_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["buyer"] != "yes")
        {
            Response.Redirect("Coder.aspx");
        }
        else
            Response.Redirect("Buyer.aspx");

    }
    protected void btnBidAProject_Click(object sender, EventArgs e)
    {
        Response.Redirect("biddetails.aspx");
    }
  
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int pid = Convert.ToInt32(GridView1.DataKeys[GridView1.SelectedIndex].Value);
        Response.Redirect("biddetails.aspx?pid="+pid);
    }

    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if(e.Row.RowIndex>-1)
        {
            if (Request.QueryString["buyer"] == "yes")
            {
                DataRowView dr = (DataRowView)e.Row.DataItem;
                // 
                //dr.Rows[e.Row.RowIndex].Cells[6].Controls[0].Visible = false;
                e.Row.Cells[6].Controls[0].Visible = false;
                
               
            }
        }
    }
}
